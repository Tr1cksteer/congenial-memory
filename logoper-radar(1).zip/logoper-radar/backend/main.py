"""
main.py — FastAPI backend для LogoperРадар
==========================================
Запуск:  uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""
import asyncio
import io
import json
import logging
import os
import re
from datetime import datetime, timezone
from typing import List, Optional

import aiosqlite
from fastapi import (
    Depends, FastAPI, File, Form, HTTPException, Request,
    UploadFile, status
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from openpyxl import Workbook
from pydantic import BaseModel

import auth
import database as db_mod
import scheduler as sched_mod
from basin_logic import determine_basin
from scraper import get_vessel_info

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# ─── App ──────────────────────────────────────────────────────────────────────

app = FastAPI(title="LogoperРадар API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")


# ─── Lifecycle ────────────────────────────────────────────────────────────────

@app.on_event("startup")
async def startup():
    await db_mod.init_db()
    sched_mod.start_scheduler()
    await sched_mod.maybe_run_now()


@app.on_event("shutdown")
async def shutdown():
    sched_mod.stop_scheduler()


# ─── Pydantic models ──────────────────────────────────────────────────────────

class LoginRequest(BaseModel):
    login: str
    password: str


class AddVesselRequest(BaseModel):
    imo: str


class VesselOut(BaseModel):
    id: int
    imo: str
    name: Optional[str]
    line: Optional[str]
    vessel_type: Optional[str]
    flag: Optional[str]
    last_port: Optional[str]
    destination: Optional[str]
    route_ports: Optional[list]
    basin: Optional[str]
    status: Optional[str]
    last_update: Optional[str]
    added_at: Optional[str]


# ─── Helper ───────────────────────────────────────────────────────────────────

def row_to_vessel(row) -> dict:
    d = dict(row)
    rp = d.get("route_ports")
    try:
        d["route_ports"] = json.loads(rp) if rp else []
    except Exception:
        d["route_ports"] = []
    return d


def validate_imo(imo: str) -> str:
    imo = imo.strip()
    clean = re.sub(r"[^0-9]", "", imo)
    if len(clean) != 7:
        raise HTTPException(400, detail=f"Неверный формат IMO: '{imo}'. Ожидается 7 цифр.")
    return clean


# ─── Auth ─────────────────────────────────────────────────────────────────────

@app.post("/api/login")
async def login(req: LoginRequest):
    if req.login != auth.ADMIN_LOGIN or not auth.verify_password(req.password):
        raise HTTPException(status_code=401, detail="Неверный логин или пароль")
    token = auth.create_token()
    return {"token": token, "login": req.login}


# ─── Public endpoints (no auth) ───────────────────────────────────────────────

@app.get("/api/vessels")
async def list_vessels_public():
    """Публичный список судов (без удаления/редактирования)."""
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        rows = await db_mod.get_all_vessels(db_conn)
    vessels = [row_to_vessel(r) for r in rows]
    return {"vessels": vessels}


@app.get("/api/stats")
async def get_stats():
    """Статистика по бассейнам для карточек."""
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        rows = await db_mod.get_all_vessels(db_conn)
        last_scrape = await db_mod.get_last_scrape(db_conn)
        next_run = await db_mod.get_setting(db_conn, "next_run")

    basin_counts: dict[str, int] = {}
    for r in rows:
        b = r["basin"] or "Неизвестно"
        basin_counts[b] = basin_counts.get(b, 0) + 1

    return {
        "total": len(rows),
        "basins": basin_counts,
        "last_scrape": dict(last_scrape) if last_scrape else None,
        "next_run": next_run,
        "scraping_now": sched_mod.is_scrape_running(),
    }


@app.get("/api/vessels/export")
async def export_xls_public():
    return await _export_xlsx()


# ─── Admin endpoints (require JWT) ────────────────────────────────────────────

@app.post("/api/admin/vessels")
async def add_vessel(
    req: AddVesselRequest,
    admin: str = Depends(auth.get_current_admin),
):
    imo = validate_imo(req.imo)
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        existing = await db_mod.get_vessel(db_conn, imo)
        if existing:
            raise HTTPException(400, detail=f"IMO {imo} уже существует в системе")
        await db_mod.upsert_vessel(db_conn, imo)

    # Запускаем фоновое обогащение нового судна
    asyncio.create_task(_enrich_single(imo))
    return {"ok": True, "imo": imo}


@app.post("/api/admin/vessels/import")
async def import_vessels_txt(
    file: UploadFile = File(...),
    admin: str = Depends(auth.get_current_admin),
):
    content = await file.read()
    text = content.decode("utf-8", errors="replace")
    raw_imos = re.findall(r"\b\d{7}\b", text)
    if not raw_imos:
        raise HTTPException(400, detail="В файле не найдено ни одного IMO-кода (7 цифр)")

    added, skipped, invalid = [], [], []
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        for raw in raw_imos:
            imo = raw.strip()
            existing = await db_mod.get_vessel(db_conn, imo)
            if existing:
                skipped.append(imo)
            else:
                await db_mod.upsert_vessel(db_conn, imo)
                added.append(imo)

    if added:
        asyncio.create_task(_enrich_many(added))

    return {"added": added, "skipped": skipped, "invalid": invalid}


@app.delete("/api/admin/vessels/{imo}")
async def delete_vessel(imo: str, admin: str = Depends(auth.get_current_admin)):
    imo = validate_imo(imo)
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        await db_mod.delete_vessel(db_conn, imo)
    return {"ok": True}


@app.post("/api/admin/vessels/delete-bulk")
async def delete_vessels_bulk(
    file: Optional[UploadFile] = File(None),
    imos_json: Optional[str] = Form(None),
    admin: str = Depends(auth.get_current_admin),
):
    imos = []
    if file:
        content = await file.read()
        text = content.decode("utf-8", errors="replace")
        imos = re.findall(r"\b\d{7}\b", text)
    elif imos_json:
        try:
            imos = json.loads(imos_json)
        except Exception:
            raise HTTPException(400, detail="Неверный JSON список IMO")

    if not imos:
        raise HTTPException(400, detail="Список IMO пуст")

    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        await db_mod.delete_vessels_bulk(db_conn, imos)
    return {"ok": True, "deleted": len(imos)}


@app.post("/api/admin/refresh")
async def manual_refresh(admin: str = Depends(auth.get_current_admin)):
    """Ручной запуск обновления флота."""
    if sched_mod.is_scrape_running():
        return {"ok": False, "message": "Обновление уже выполняется"}
    asyncio.create_task(sched_mod.run_scrape_job())
    return {"ok": True, "message": "Обновление запущено"}


@app.get("/api/admin/vessels/export")
async def export_xls_admin(admin: str = Depends(auth.get_current_admin)):
    return await _export_xlsx()


# ─── Helpers ──────────────────────────────────────────────────────────────────

async def _enrich_single(imo: str):
    """Фоновое обогащение одного только добавленного судна."""
    import asyncio as _as
    await _as.sleep(0.5)
    try:
        info = await get_vessel_info(imo)
        route_ports = info.get("route_ports") or []
        basin, vessel_status = determine_basin(
            route_ports,
            destination=info.get("destination") or "",
            last_port=info.get("last_port") or "",
        )
        data = {
            "name":        info.get("name") or f"IMO {imo}",
            "line":        info.get("line"),
            "vessel_type": info.get("vessel_type"),
            "flag":        info.get("flag"),
            "last_port":   info.get("last_port"),
            "destination": info.get("destination"),
            "route_ports": json.dumps(route_ports, ensure_ascii=False),
            "basin":       basin,
            "status":      vessel_status,
            "last_update": datetime.now(timezone.utc).isoformat(),
        }
        async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
            db_conn.row_factory = aiosqlite.Row
            await db_mod.update_vessel_data(db_conn, imo, data)
        logger.info(f"Enriched {imo}: {data.get('name')} → {basin}")
    except Exception as e:
        logger.error(f"Enrich error for {imo}: {e}")


async def _enrich_many(imos: list[str]):
    """Обогатить список новых судов."""
    from scraper import scrape_all_vessels
    import asyncio as _as
    await _as.sleep(1)
    results = await scrape_all_vessels(imos, delay=2.0)
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        for info in results:
            imo = info.get("imo")
            if not imo:
                continue
            route_ports = info.get("route_ports") or []
            basin, vessel_status = determine_basin(
                route_ports,
                destination=info.get("destination") or "",
                last_port=info.get("last_port") or "",
            )
            data = {
                "name":        info.get("name") or f"IMO {imo}",
                "line":        info.get("line"),
                "vessel_type": info.get("vessel_type"),
                "flag":        info.get("flag"),
                "last_port":   info.get("last_port"),
                "destination": info.get("destination"),
                "route_ports": json.dumps(route_ports, ensure_ascii=False),
                "basin":       basin,
                "status":      vessel_status,
                "last_update": datetime.now(timezone.utc).isoformat(),
            }
            await db_mod.update_vessel_data(db_conn, imo, data)


async def _export_xlsx():
    async with aiosqlite.connect(db_mod.DB_PATH) as db_conn:
        db_conn.row_factory = aiosqlite.Row
        rows = await db_mod.get_all_vessels(db_conn)

    wb = Workbook()
    ws = wb.active
    ws.title = "Флот"
    headers = ["IMO", "Название судна", "Линия", "Тип", "Флаг",
               "Последний порт", "Назначение", "Бассейн", "Статус", "Обновлено"]
    ws.append(headers)

    for r in rows:
        ws.append([
            r["imo"], r["name"], r["line"], r["vessel_type"], r["flag"],
            r["last_port"], r["destination"], r["basin"], r["status"],
            r["last_update"],
        ])

    # Ширина столбцов
    for col in ws.columns:
        max_len = max((len(str(c.value or "")) for c in col), default=10)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)

    filename = f"logoper_radar_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ─── Static frontend ──────────────────────────────────────────────────────────

if os.path.isdir(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
