"""
scheduler.py
============
APScheduler запускает обновление флота каждые 3 дня.
При старте приложения: если прошло > 3 дней с последнего обновления → запускает сразу.
"""
import asyncio
import logging
from datetime import datetime, timezone, timedelta

import aiosqlite
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from database import DB_PATH, get_setting, set_setting, get_all_vessels, update_vessel_data, log_scrape
from scraper import scrape_all_vessels
from basin_logic import determine_basin

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler()
_is_running = False


async def run_scrape_job():
    """Основная задача: обновляет данные всех судов в БД."""
    global _is_running
    if _is_running:
        logger.info("Scrape already running, skip.")
        return
    _is_running = True

    started_at = datetime.now(timezone.utc).isoformat()
    ok_count = err_count = 0

    try:
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            vessels = await get_all_vessels(db)
            imos = [v["imo"] for v in vessels]

        if not imos:
            logger.info("No vessels to scrape.")
            return

        logger.info(f"Starting scrape for {len(imos)} vessels…")
        results = await scrape_all_vessels(imos, delay=2.5)

        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            for info in results:
                imo = info.get("imo")
                if not imo:
                    continue
                try:
                    route_ports = info.get("route_ports") or []
                    basin, status = determine_basin(
                        route_ports,
                        destination=info.get("destination") or "",
                        last_port=info.get("last_port") or "",
                    )
                    import json
                    data = {
                        "name":        info.get("name") or f"IMO {imo}",
                        "line":        info.get("line"),
                        "vessel_type": info.get("vessel_type"),
                        "flag":        info.get("flag"),
                        "last_port":   info.get("last_port"),
                        "destination": info.get("destination"),
                        "route_ports": json.dumps(route_ports, ensure_ascii=False),
                        "basin":       basin,
                        "status":      status,
                        "last_update": datetime.now(timezone.utc).isoformat(),
                    }
                    await update_vessel_data(db, imo, data)
                    ok_count += 1
                except Exception as e:
                    logger.error(f"Error updating vessel {imo}: {e}")
                    err_count += 1

            finished_at = datetime.now(timezone.utc).isoformat()
            await log_scrape(db, started_at, finished_at, ok_count, err_count)

            # Следующий запуск через 3 дня
            next_run = (datetime.now(timezone.utc) + timedelta(days=3)).isoformat()
            await set_setting(db, "next_run", next_run)
            await set_setting(db, "last_run", finished_at)

        logger.info(f"Scrape done: {ok_count} ok, {err_count} errors. Next run: {next_run}")

    except Exception as e:
        logger.error(f"Scrape job fatal error: {e}")
    finally:
        _is_running = False


async def maybe_run_now():
    """Запустить сразу при старте если прошло > 3 дней."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        next_run_str = await get_setting(db, "next_run")
    if next_run_str:
        try:
            next_run = datetime.fromisoformat(next_run_str)
            if next_run.tzinfo is None:
                next_run = next_run.replace(tzinfo=timezone.utc)
            if datetime.now(timezone.utc) >= next_run:
                logger.info("Overdue scrape — running immediately.")
                asyncio.create_task(run_scrape_job())
        except Exception as e:
            logger.warning(f"Could not parse next_run: {e}")


def start_scheduler():
    """Вызывается при старте FastAPI."""
    scheduler.add_job(
        run_scrape_job,
        trigger="interval",
        days=3,
        id="scrape_fleet",
        replace_existing=True,
    )
    scheduler.start()
    logger.info("Scheduler started (interval: 3 days).")


def stop_scheduler():
    scheduler.shutdown(wait=False)


def is_scrape_running() -> bool:
    return _is_running
