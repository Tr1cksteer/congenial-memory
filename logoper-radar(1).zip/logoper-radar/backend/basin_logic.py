"""
basin_logic.py
==============
Определяет «бассейн» судна на основе портов захода.

Бассейны:
  ДВ             – Владивосток / Находка (с заходом в другие страны)
  ДВ без РФ      – не заходит ни в один порт РФ, работает на ДВ-направлении
  ДВ каботаж     – Владивосток/Находка + Камчатка/Сахалин, только РФ
  Балтийский     – СПб / Калининград (с заходом в другие страны)
  Балтика каботаж– только СПб ↔ Калининград (кольцо, только РФ)
  Азово-Черноморский – Новороссийск / Туапсе / Тамань / Темрюк (+ м.б. Ростов)
  Каботаж        – исключительно порты РФ, не попадают в другие категории
  Транзит        – нет портов РФ
"""

# ── Словари портов ────────────────────────────────────────────────────────────

FAR_EAST_RF = {
    "владивосток", "vladivostok",
    "находка", "nakhodka", "vostochny", "восточный",
    "петропавловск-камчатский", "petropavlovsk", "petropavlovsk-kamchatsky",
    "холмск", "kholmsk", "корсаков", "korsakov",
    "магадан", "magadan",
    "де-кастри", "de-kastri",
    "ванино", "vanino",
    "советская гавань", "sovetskaya gavan",
}

FAR_EAST_CABOTAGE_EXTRA = {
    "петропавловск-камчатский", "petropavlovsk", "petropavlovsk-kamchatsky",
    "холмск", "kholmsk", "корсаков", "korsakov",
    "магадан", "magadan",
}

BALTIC_RF = {
    "санкт-петербург", "saint petersburg", "st. petersburg", "st petersburg",
    "спб", "spb", "большой порт",
    "калининград", "kaliningrad",
    "усть-луга", "ust-luga", "приморск", "primorsk",
    "высоцк", "vysotsk",
}

BLACK_SEA_RF = {
    "новороссийск", "novorossiysk", "novorossiisk",
    "туапсе", "tuapse",
    "тамань", "taman",
    "темрюк", "temryuk",
    "ростов", "rostov",
    "азов", "azov",
}

ALL_RF_PORTS = FAR_EAST_RF | BALTIC_RF | BLACK_SEA_RF | {
    "архангельск", "arkhangelsk",
    "мурманск", "murmansk",
    "сабетта", "sabetta",
    "дудинка", "dudinka",
}


def _norm(port: str) -> str:
    return port.strip().lower()


def _in_set(port_norm: str, port_set: set) -> bool:
    return any(p in port_norm or port_norm in p for p in port_set)


def determine_basin(route_ports: list[str], destination: str = "", last_port: str = "") -> tuple[str, str]:
    """
    Returns (basin_name, status)
    status: 'Транзит' | 'Регулярный' | 'Каботаж'
    """
    # Собираем все упомянутые порты в один список для анализа
    all_mentions = [_norm(p) for p in route_ports]
    if destination:
        all_mentions.append(_norm(destination))
    if last_port:
        all_mentions.append(_norm(last_port))

    if not all_mentions:
        return "Неизвестно", "Неизвестно"

    # Флаги присутствия
    has_fe_rf    = any(_in_set(p, FAR_EAST_RF)    for p in all_mentions)
    has_baltic_rf= any(_in_set(p, BALTIC_RF)       for p in all_mentions)
    has_black_rf = any(_in_set(p, BLACK_SEA_RF)    for p in all_mentions)
    has_any_rf   = any(_in_set(p, ALL_RF_PORTS)    for p in all_mentions)

    # Порты вне РФ: если хотя бы один порт в маршруте не входит в ALL_RF_PORTS
    non_rf = [
        p for p in all_mentions
        if p and not _in_set(p, ALL_RF_PORTS)
    ]
    has_non_rf = len(non_rf) > 0

    # ── 1. Нет ни одного порта РФ → транзит/ДВ без РФ ────────────────────────
    if not has_any_rf:
        return "ДВ без РФ", "Транзит"

    # ── 2. Черноморский ───────────────────────────────────────────────────────
    if has_black_rf:
        status = "Регулярный" if has_non_rf else "Каботаж"
        return "Азово-Черноморский", status

    # ── 3. Балтийский ─────────────────────────────────────────────────────────
    if has_baltic_rf:
        if not has_non_rf:
            # только порты РФ
            spb   = any(_in_set(p, {"санкт-петербург","saint petersburg","st. petersburg","st petersburg","спб","spb","большой порт"}) for p in all_mentions)
            kal   = any(_in_set(p, {"калининград","kaliningrad"}) for p in all_mentions)
            if spb and kal:
                return "Балтика каботаж", "Каботаж"
            return "Балтийский", "Каботаж"
        return "Балтийский", "Регулярный"

    # ── 4. Дальний Восток ────────────────────────────────────────────────────
    if has_fe_rf:
        if not has_non_rf:
            # только порты РФ — проверяем каботаж ДВ
            fe_ports = [p for p in all_mentions if _in_set(p, FAR_EAST_RF)]
            base_fe  = [p for p in fe_ports if _in_set(p, {"владивосток","vladivostok","находка","nakhodka","vostochny","восточный"})]
            extra_fe = [p for p in fe_ports if _in_set(p, FAR_EAST_CABOTAGE_EXTRA)]
            if base_fe and extra_fe:
                return "ДВ каботаж", "Каботаж"
            return "ДВ", "Каботаж"
        return "ДВ", "Регулярный"

    # ── 5. Прочие порты РФ без заходов за рубеж → общий каботаж ─────────────
    if not has_non_rf:
        return "Каботаж", "Каботаж"

    return "Неизвестно", "Транзит"
