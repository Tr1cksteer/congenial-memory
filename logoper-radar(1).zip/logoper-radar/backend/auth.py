"""
auth.py — простая JWT-аутентификация для одного администратора.
Логин/пароль хранится в переменных окружения.
"""
import os
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from passlib.context import CryptContext

SECRET_KEY   = os.environ.get("SECRET_KEY", "logoper-radar-super-secret-key-change-me")
ALGORITHM    = "HS256"
TOKEN_EXPIRE = int(os.environ.get("TOKEN_EXPIRE_HOURS", "72"))

ADMIN_LOGIN  = os.environ.get("ADMIN_LOGIN",    "admin")
ADMIN_PASS   = os.environ.get("ADMIN_PASSWORD", "radar2026")

pwd_ctx  = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer(auto_error=False)

# Хэш пароля вычисляется один раз при запуске
_PASS_HASH = pwd_ctx.hash(ADMIN_PASS)


def verify_password(plain: str) -> bool:
    return pwd_ctx.verify(plain, _PASS_HASH)


def create_token() -> str:
    expire = datetime.now(timezone.utc) + timedelta(hours=TOKEN_EXPIRE)
    return jwt.encode({"sub": ADMIN_LOGIN, "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None


async def get_current_admin(
    creds: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> str:
    if creds is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    user = decode_token(creds.credentials)
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
    return user
