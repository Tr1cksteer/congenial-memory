"""
scraper.py
==========
Парсит данные о судне по IMO-коду с открытых источников (без API-ключей):
  1. goradar.ru  — расписание портов захода
  2. myshiptracking.com — запасной источник

Возвращает dict с полями:
  name, line, vessel_type, flag, last_port, destination, route_ports
"""
import asyncio
import re
import json
import logging
from typing import Optional

import aiohttp
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
    "Accept": "text/html,application/xhtml+xml,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}

TIMEOUT = aiohttp.ClientTimeout(total=30)


async def _fetch(session: aiohttp.ClientSession, url: str, **kwargs) -> str:
    try:
        async with session.get(url, headers=HEADERS, timeout=TIMEOUT, ssl=False, **kwargs) as resp:
            resp.raise_for_status()
            return await resp.text(errors="replace")
    except Exception as e:
        logger.warning(f"Fetch error {url}: {e}")
        return ""


# ─── goradar.ru ───────────────────────────────────────────────────────────────

async def scrape_goradar(session: aiohttp.ClientSession, imo: str) -> Optional[dict]:
    """
    Пробует найти судно на goradar.ru по IMO.
    URL: https://goradar.ru/vessels?imo=<IMO>
    """
    search_url = f"https://goradar.ru/vessels?imo={imo}"
    html = await _fetch(session, search_url)
    if not html:
        return None

    soup = BeautifulSoup(html, "lxml")

    # Найти ссылку на страницу судна
    vessel_link = None
    for a in soup.select("a[href]"):
        href = a.get("href", "")
        if "/vessel/" in href or "/vessels/" in href:
            vessel_link = href if href.startswith("http") else "https://goradar.ru" + href
            break

    if not vessel_link:
        # Попробовать прямой URL
        vessel_link = f"https://goradar.ru/vessel/{imo}"

    vessel_html = await _fetch(session, vessel_link)
    if not vessel_html:
        return None

    return _parse_goradar_vessel(vessel_html, imo)


def _parse_goradar_vessel(html: str, imo: str) -> Optional[dict]:
    soup = BeautifulSoup(html, "lxml")
    data: dict = {"imo": imo}

    # Название судна
    name_el = soup.find("h1") or soup.find(class_=re.compile(r"vessel.?name|ship.?name", re.I))
    if name_el:
        data["name"] = name_el.get_text(strip=True)

    # Таблица характеристик
    for row in soup.select("table tr, dl dt, .info-row, .vessel-info tr"):
        cells = row.find_all(["td", "dd", "span"])
        if len(cells) >= 2:
            key   = cells[0].get_text(strip=True).lower()
            value = cells[1].get_text(strip=True)
            if "тип" in key or "type" in key:
                data["vessel_type"] = value
            elif "флаг" in key or "flag" in key:
                data["flag"] = value
            elif "линия" in key or "line" in key or "оператор" in key or "operator" in key:
                data["line"] = value
            elif "последний" in key or "last port" in key or "откуда" in key:
                data["last_port"] = value
            elif "назначение" in key or "destination" in key or "куда" in key:
                data["destination"] = value

    # Порты захода из расписания
    route_ports = []
    for el in soup.select(".port-name, .port, td.port, .schedule-port, .call-port, [class*=port]"):
        t = el.get_text(strip=True)
        if t and len(t) > 2:
            route_ports.append(t)

    # Fallback: ищем порты в общем тексте таблиц
    if not route_ports:
        for table in soup.select("table"):
            headers = [th.get_text(strip=True).lower() for th in table.select("th")]
            port_col = None
            for i, h in enumerate(headers):
                if "порт" in h or "port" in h:
                    port_col = i
                    break
            if port_col is not None:
                for row in table.select("tr"):
                    cells = row.find_all("td")
                    if len(cells) > port_col:
                        t = cells[port_col].get_text(strip=True)
                        if t and len(t) > 2:
                            route_ports.append(t)

    data["route_ports"] = list(dict.fromkeys(route_ports))  # deduplicate, keep order
    return data if data.get("name") else None


# ─── myshiptracking.com ───────────────────────────────────────────────────────

async def scrape_myshiptracking(session: aiohttp.ClientSession, imo: str) -> Optional[dict]:
    """
    Запасной источник: myshiptracking.com
    """
    url = f"https://www.myshiptracking.com/?imo={imo}"
    html = await _fetch(session, url)
    if not html:
        return None
    return _parse_myshiptracking(html, imo)


def _parse_myshiptracking(html: str, imo: str) -> Optional[dict]:
    soup = BeautifulSoup(html, "lxml")
    data: dict = {"imo": imo}

    # Название
    for sel in ["h1.vessel-name", "h1", ".vessel-title", "title"]:
        el = soup.select_one(sel)
        if el:
            t = el.get_text(strip=True)
            if t and t.lower() not in ("myshiptracking", ""):
                data["name"] = t.split("|")[0].strip()
                break

    # Характеристики
    for li in soup.select("li.item, .info-item, .vessel-detail"):
        text = li.get_text(" ", strip=True)
        for kw, field in [
            ("Flag", "flag"), ("Флаг", "flag"),
            ("Type", "vessel_type"), ("Тип", "vessel_type"),
            ("Destination", "destination"), ("Назначение", "destination"),
            ("Last Port", "last_port"), ("Последний порт", "last_port"),
        ]:
            if kw.lower() in text.lower():
                parts = text.split(":", 1)
                if len(parts) == 2:
                    data[field] = parts[1].strip()
                break

    route_ports = []
    for el in soup.select(".port-of-call, .port, td[class*=port]"):
        t = el.get_text(strip=True)
        if t:
            route_ports.append(t)
    data["route_ports"] = list(dict.fromkeys(route_ports))
    return data if data.get("name") else None


# ─── vessel-finder.com ────────────────────────────────────────────────────────

async def scrape_vesselfinder(session: aiohttp.ClientSession, imo: str) -> Optional[dict]:
    """Третий запасной источник."""
    url = f"https://www.vesselfinder.com/?imo={imo}"
    html = await _fetch(session, url)
    if not html:
        return None

    soup = BeautifulSoup(html, "lxml")
    data: dict = {"imo": imo, "route_ports": []}

    # Попробуем найти JSON-LD или meta
    for script in soup.select("script[type='application/ld+json']"):
        try:
            j = json.loads(script.string or "")
            if isinstance(j, dict) and j.get("name"):
                data["name"] = j["name"]
                break
        except Exception:
            pass

    if not data.get("name"):
        h1 = soup.find("h1")
        if h1:
            data["name"] = h1.get_text(strip=True)

    for item in soup.select(".vfi-details-table td, .details-row"):
        text = item.get_text(" ", strip=True)
        if "Flag" in text:
            data["flag"] = text.replace("Flag", "").strip()
        elif "Type" in text:
            data["vessel_type"] = text.replace("Type", "").strip()
        elif "Destination" in text:
            data["destination"] = text.replace("Destination", "").strip()
        elif "Last Port" in text:
            data["last_port"] = text.replace("Last Port", "").strip()

    return data if data.get("name") else None


# ─── Основная функция ─────────────────────────────────────────────────────────

async def get_vessel_info(imo: str) -> dict:
    """
    Пробует источники по порядку, возвращает наиболее полный результат.
    """
    base: dict = {
        "imo": imo,
        "name": None,
        "line": None,
        "vessel_type": None,
        "flag": None,
        "last_port": None,
        "destination": None,
        "route_ports": [],
    }

    async with aiohttp.ClientSession() as session:
        # 1) goradar.ru
        try:
            result = await scrape_goradar(session, imo)
            if result and result.get("name"):
                base.update({k: v for k, v in result.items() if v})
                if base["route_ports"] or base["destination"]:
                    return base
        except Exception as e:
            logger.warning(f"goradar failed for {imo}: {e}")

        await asyncio.sleep(1)

        # 2) myshiptracking
        try:
            result = await scrape_myshiptracking(session, imo)
            if result and result.get("name"):
                for k, v in result.items():
                    if v and not base.get(k):
                        base[k] = v
                if base["route_ports"] or base["destination"]:
                    return base
        except Exception as e:
            logger.warning(f"myshiptracking failed for {imo}: {e}")

        await asyncio.sleep(1)

        # 3) vesselfinder
        try:
            result = await scrape_vesselfinder(session, imo)
            if result and result.get("name"):
                for k, v in result.items():
                    if v and not base.get(k):
                        base[k] = v
        except Exception as e:
            logger.warning(f"vesselfinder failed for {imo}: {e}")

    return base


async def scrape_all_vessels(imos: list[str], delay: float = 2.0) -> list[dict]:
    """Парсит все суда с задержкой между запросами."""
    results = []
    for imo in imos:
        try:
            info = await get_vessel_info(imo)
            results.append(info)
        except Exception as e:
            logger.error(f"Error scraping {imo}: {e}")
            results.append({"imo": imo, "route_ports": [], "name": None})
        await asyncio.sleep(delay)
    return results
