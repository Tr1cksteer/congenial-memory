"""
SQLite database layer using aiosqlite.
Tables:
  - vessels      : tracked IMO codes + enriched data
  - scrape_log   : log of every scrape run
  - settings     : key/value config (next_run, etc.)
"""
import aiosqlite
import os

DB_PATH = os.environ.get("DB_PATH", "radar.db")


async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS vessels (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                imo         TEXT    NOT NULL UNIQUE,
                name        TEXT,
                line        TEXT,
                vessel_type TEXT,
                flag        TEXT,
                last_port   TEXT,
                destination TEXT,
                route_ports TEXT,   -- JSON array of port names from schedule
                basin       TEXT,
                status      TEXT,   -- 'Транзит' | 'Регулярный' | 'Каботаж' | 'Неизвестно'
                last_update TEXT,   -- ISO datetime
                added_at    TEXT    DEFAULT (datetime('now'))
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS scrape_log (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at  TEXT,
                finished_at TEXT,
                vessels_ok  INTEGER DEFAULT 0,
                vessels_err INTEGER DEFAULT 0,
                notes       TEXT
            )
        """)
        await db.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        # default next_run = now (so first run happens immediately on scheduler start)
        await db.execute("""
            INSERT OR IGNORE INTO settings(key, value)
            VALUES ('next_run', datetime('now'))
        """)
        await db.commit()


async def get_db():
    """Dependency-style async context manager."""
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        yield db


# ── vessel CRUD ────────────────────────────────────────────────────────────────

async def upsert_vessel(db, imo: str):
    """Add IMO if not present."""
    await db.execute(
        "INSERT OR IGNORE INTO vessels(imo) VALUES (?)", (imo,)
    )
    await db.commit()


async def update_vessel_data(db, imo: str, data: dict):
    fields = ", ".join(f"{k} = ?" for k in data)
    values = list(data.values()) + [imo]
    await db.execute(f"UPDATE vessels SET {fields} WHERE imo = ?", values)
    await db.commit()


async def delete_vessel(db, imo: str):
    await db.execute("DELETE FROM vessels WHERE imo = ?", (imo,))
    await db.commit()


async def delete_vessels_bulk(db, imos: list[str]):
    await db.executemany("DELETE FROM vessels WHERE imo = ?", [(i,) for i in imos])
    await db.commit()


async def get_all_vessels(db):
    async with db.execute(
        "SELECT * FROM vessels ORDER BY name ASC, imo ASC"
    ) as cur:
        return await cur.fetchall()


async def get_vessel(db, imo: str):
    async with db.execute("SELECT * FROM vessels WHERE imo = ?", (imo,)) as cur:
        return await cur.fetchone()


# ── settings ───────────────────────────────────────────────────────────────────

async def get_setting(db, key: str, default=None):
    async with db.execute("SELECT value FROM settings WHERE key = ?", (key,)) as cur:
        row = await cur.fetchone()
        return row["value"] if row else default


async def set_setting(db, key: str, value: str):
    await db.execute(
        "INSERT OR REPLACE INTO settings(key, value) VALUES (?, ?)", (key, value)
    )
    await db.commit()


# ── scrape log ─────────────────────────────────────────────────────────────────

async def log_scrape(db, started_at, finished_at, ok, err, notes=""):
    await db.execute(
        """INSERT INTO scrape_log(started_at, finished_at, vessels_ok, vessels_err, notes)
           VALUES (?, ?, ?, ?, ?)""",
        (started_at, finished_at, ok, err, notes),
    )
    await db.commit()


async def get_last_scrape(db):
    async with db.execute(
        "SELECT * FROM scrape_log ORDER BY id DESC LIMIT 1"
    ) as cur:
        return await cur.fetchone()
